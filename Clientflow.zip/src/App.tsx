import React, { useState } from 'react';
import { CRMProvider, useCRM } from './context/CRMContext';
import { Header } from './components/layout/Header';
import { DashboardView } from './components/dashboard/DashboardView';
import { LeadsListView } from './components/leads/LeadsListView';
import { LeadDetailView } from './components/leads/LeadDetailView';
import { LeadFormModal } from './components/leads/LeadFormModal';
import { OpportunitiesView } from './components/opportunities/OpportunitiesView';
import { OpportunityDetailView } from './components/opportunities/OpportunityDetailView';
import { OpportunityFormModal } from './components/opportunities/OpportunityFormModal';
import { FollowUpsView } from './components/followups/FollowUpsView';
import { FollowUpFormModal } from './components/followups/FollowUpFormModal';
import { ExportView } from './components/export/ExportView';
import { AuthModal } from './components/auth/AuthModal';
import { ToastContainer } from './components/common/Toast';
import { Lead, Opportunity, FollowUp } from './types/crm';

const CRMMainContent: React.FC = () => {
  const { 
    currentTab, 
    setCurrentTab,
    selectedLeadId, 
    setSelectedLeadId,
    selectedOpportunityId, 
    setSelectedOpportunityId,
    leads,
    opportunities,
    currentWorkspace
  } = useCRM();

  // Modals state
  const [leadModalOpen, setLeadModalOpen] = useState(false);
  const [leadToEdit, setLeadToEdit] = useState<Lead | null>(null);

  const [oppModalOpen, setOppModalOpen] = useState(false);
  const [oppToEdit, setOppToEdit] = useState<Opportunity | null>(null);
  const [preselectedLeadForOpp, setPreselectedLeadForOpp] = useState<string | undefined>(undefined);

  const [followUpModalOpen, setFollowUpModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<FollowUp | null>(null);
  const [preselectedLeadForTask, setPreselectedLeadForTask] = useState<string | undefined>(undefined);
  const [preselectedOppForTask, setPreselectedOppForTask] = useState<string | undefined>(undefined);

  const [authModalOpen, setAuthModalOpen] = useState(false);

  // Handlers for modal triggers
  const handleOpenNewLead = () => {
    setLeadToEdit(null);
    setLeadModalOpen(true);
  };

  const handleEditLead = (leadId: string) => {
    const l = leads.find(item => item.id === leadId);
    if (l) {
      setLeadToEdit(l);
      setLeadModalOpen(true);
    }
  };

  const handleOpenNewOpportunity = (leadId?: string) => {
    setOppToEdit(null);
    setPreselectedLeadForOpp(leadId);
    setOppModalOpen(true);
  };

  const handleEditOpportunity = (oppId: string) => {
    const o = opportunities.find(item => item.id === oppId);
    if (o) {
      setOppToEdit(o);
      setOppModalOpen(true);
    }
  };

  const handleOpenNewFollowUp = (leadId?: string, oppId?: string) => {
    setTaskToEdit(null);
    setPreselectedLeadForTask(leadId);
    setPreselectedOppForTask(oppId);
    setFollowUpModalOpen(true);
  };

  const handleRescheduleFollowUp = (task: FollowUp) => {
    setTaskToEdit(task);
    setFollowUpModalOpen(true);
  };

  // Callback when a lead is created with the "immediately create opportunity" option checked
  const handleLeadCreated = (newLeadId: string, openOppForm: boolean) => {
    if (openOppForm) {
      handleOpenNewOpportunity(newLeadId);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 selection:bg-slate-900 selection:text-white">
      {/* Header following strict Top Bar Contract */}
      <Header
        onOpenNewLead={handleOpenNewLead}
        onOpenNewOpportunity={() => handleOpenNewOpportunity()}
        onOpenNewFollowUp={() => handleOpenNewFollowUp()}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      {/* Main Viewport Container (Baseline 1440px presence with responsive padding) */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Lead Detail View */}
        {selectedLeadId ? (
          <LeadDetailView
            leadId={selectedLeadId}
            onBack={() => setSelectedLeadId(null)}
            onEditLead={() => handleEditLead(selectedLeadId)}
            onAddOpportunityForLead={() => handleOpenNewOpportunity(selectedLeadId)}
            onScheduleFollowUpForLead={() => handleOpenNewFollowUp(selectedLeadId)}
          />
        ) : selectedOpportunityId ? (
          /* Opportunity Detail View */
          <OpportunityDetailView
            opportunityId={selectedOpportunityId}
            onBack={() => setSelectedOpportunityId(null)}
            onEdit={() => handleEditOpportunity(selectedOpportunityId)}
            onScheduleFollowUp={() => {
              const opp = opportunities.find(o => o.id === selectedOpportunityId);
              handleOpenNewFollowUp(opp?.leadId, selectedOpportunityId);
            }}
          />
        ) : (
          /* Tab Navigation Views */
          <>
            {currentTab === 'dashboard' && (
              <DashboardView
                onOpenNewLead={handleOpenNewLead}
                onOpenNewOpportunity={() => handleOpenNewOpportunity()}
                onOpenNewFollowUp={() => handleOpenNewFollowUp()}
              />
            )}

            {currentTab === 'leads' && (
              <LeadsListView
                onOpenNewLead={handleOpenNewLead}
                onSelectLead={(id) => setSelectedLeadId(id)}
              />
            )}

            {currentTab === 'opportunities' && (
              <OpportunitiesView
                onOpenNewOpportunity={() => handleOpenNewOpportunity()}
                onSelectOpportunity={(id) => setSelectedOpportunityId(id)}
              />
            )}

            {currentTab === 'followups' && (
              <FollowUpsView
                onOpenNewFollowUp={() => handleOpenNewFollowUp()}
                onRescheduleFollowUp={handleRescheduleFollowUp}
                onOpenLead={(leadId) => {
                  setSelectedLeadId(leadId);
                  setCurrentTab('leads');
                }}
                onOpenOpportunity={(oppId) => {
                  setSelectedOpportunityId(oppId);
                  setCurrentTab('opportunities');
                }}
              />
            )}

            {currentTab === 'export' && <ExportView />}
          </>
        )}

      </main>

      {/* Clean Footnote (no pseudo-telemetry or fake tickers) */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-800">ClientFlow</span>
            <span aria-hidden="true">·</span>
            <span>Small Business CRM</span>
            <span aria-hidden="true">·</span>
            <span>Workspace: {currentWorkspace.name}</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <span>Deterministic Reporting</span>
            <span>Local Record Integrity</span>
            <span>RFC4180 Export</span>
          </div>
        </div>
      </footer>

      {/* Modals & Dialogs */}
      <LeadFormModal
        isOpen={leadModalOpen}
        onClose={() => setLeadModalOpen(false)}
        leadToEdit={leadToEdit}
        onLeadCreated={handleLeadCreated}
      />

      <OpportunityFormModal
        isOpen={oppModalOpen}
        onClose={() => {
          setOppModalOpen(false);
          setPreselectedLeadForOpp(undefined);
        }}
        opportunityToEdit={oppToEdit}
        preselectedLeadId={preselectedLeadForOpp}
      />

      <FollowUpFormModal
        isOpen={followUpModalOpen}
        onClose={() => {
          setFollowUpModalOpen(false);
          setPreselectedLeadForTask(undefined);
          setPreselectedOppForTask(undefined);
        }}
        taskToEdit={taskToEdit}
        preselectedLeadId={preselectedLeadForTask}
        preselectedOpportunityId={preselectedOppForTask}
      />

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />

      {/* Notification Toasts */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <CRMProvider>
      <CRMMainContent />
    </CRMProvider>
  );
}

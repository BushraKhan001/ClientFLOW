import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { X, Building2, Plus, LogIn, AlertCircle } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { 
    workspaces, 
    currentWorkspace, 
    switchWorkspace, 
    createWorkspace, 
    currentUser, 
    signIn, 
    signOut 
  } = useCRM();

  const [mode, setMode] = useState<'workspace' | 'login' | 'register'>('workspace');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [newWorkspaceName, setNewWorkspaceName] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid work email.');
      return;
    }
    if (!password.trim() || password.length < 4) {
      setError('Password must be at least 4 characters.');
      return;
    }
    setError('');
    signIn(email.trim());
    setMode('workspace');
  };

  const handleCreateWorkspace = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWorkspaceName.trim()) {
      setError('Workspace name is required.');
      return;
    }
    setError('');
    createWorkspace(newWorkspaceName.trim());
    setNewWorkspaceName('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div 
        className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        role="dialog"
      >
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {mode === 'workspace' && 'Business Workspaces & Session'}
              {mode === 'login' && 'Sign in to ClientFlow'}
              {mode === 'register' && 'Create Workspace Account'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Manage workspace access and multi-business isolation
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-md text-xs text-rose-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {mode === 'workspace' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Active Workspace
                </label>
                <div className="space-y-2">
                  {workspaces.map(ws => (
                    <button
                      key={ws.id}
                      onClick={() => {
                        switchWorkspace(ws.id);
                        onClose();
                      }}
                      className={`w-full text-left p-3 rounded-lg border text-xs flex items-center justify-between transition-all ${
                        ws.id === currentWorkspace.id
                          ? 'border-slate-900 bg-slate-50 font-semibold text-slate-900'
                          : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Building2 className="w-4 h-4 text-slate-500" />
                        <div>
                          <div>{ws.name}</div>
                          <div className="text-[11px] text-slate-400 font-normal">
                            Owner: {ws.ownerEmail}
                          </div>
                        </div>
                      </div>
                      {ws.id === currentWorkspace.id && (
                        <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
                          Active
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Create new workspace */}
              <form onSubmit={handleCreateWorkspace} className="pt-3 border-t border-slate-100 space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  Create Another Workspace
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newWorkspaceName}
                    onChange={e => setNewWorkspaceName(e.target.value)}
                    placeholder="e.g. Apex Consulting LLC"
                    className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors shrink-0"
                  >
                    Create
                  </button>
                </div>
              </form>

              {/* User session status */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <div>
                  Signed in as: <strong className="text-slate-800">{currentUser ? currentUser.email : 'Guest'}</strong>
                </div>
                {currentUser ? (
                  <button
                    onClick={signOut}
                    className="text-rose-600 hover:underline font-medium"
                  >
                    Sign Out
                  </button>
                ) : (
                  <button
                    onClick={() => setMode('login')}
                    className="text-slate-900 hover:underline font-semibold"
                  >
                    Sign In
                  </button>
                )}
              </div>
            </div>
          )}

          {(mode === 'login' || mode === 'register') && (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Work Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="name@business.com"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setMode('workspace')}
                  className="text-xs text-slate-500 hover:text-slate-800"
                >
                  ← Back to Workspaces
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors"
                >
                  {mode === 'login' ? 'Sign In' : 'Create Account'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

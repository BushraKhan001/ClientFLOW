import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { 
  Download, 
  FileText, 
  Database, 
  CheckCircle2, 
  ShieldCheck,
  Building,
  Users,
  Briefcase,
  Clock
} from 'lucide-react';

export const ExportView: React.FC = () => {
  const { currentWorkspace, leads, opportunities, followUps, exportData } = useCRM();

  const [format, setFormat] = useState<'csv' | 'json'>('csv');
  const [entityType, setEntityType] = useState<'all' | 'leads' | 'opportunities' | 'followups'>('all');
  const [downloading, setDownloading] = useState(false);

  const handleExport = () => {
    setDownloading(true);
    setTimeout(() => {
      exportData(format, entityType);
      setDownloading(false);
    }, 400);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      
      {/* Header */}
      <div className="pb-4 border-b border-slate-200">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Data Export & Backup
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Download structured records for {currentWorkspace.name}. Retain complete control and ownership of your sales data.
        </p>
      </div>

      {/* Security & Workspace Notice */}
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3 text-xs text-slate-700">
        <ShieldCheck className="w-5 h-5 text-slate-600 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-semibold text-slate-900">
            Workspace Data Isolation Enforced
          </div>
          <p className="text-slate-600 leading-relaxed">
            Exports strictly encompass authorized records belonging to <strong className="text-slate-900">{currentWorkspace.name}</strong>. Dates, financial values, and historical statuses follow RFC4180 standard formatting.
          </p>
        </div>
      </div>

      {/* Configuration Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Record Type Selector */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4 shadow-xs">
          <h2 className="text-sm font-semibold text-slate-900">
            1. Select Records to Export
          </h2>

          <div className="space-y-2 text-xs">
            <label className="flex items-center gap-3 p-3 rounded-md border cursor-pointer transition-colors hover:bg-slate-50">
              <input
                type="radio"
                name="entityType"
                checked={entityType === 'all'}
                onChange={() => setEntityType('all')}
                className="text-slate-900 focus:ring-slate-900"
              />
              <div className="flex-1">
                <span className="font-semibold text-slate-900">Complete Workspace Package</span>
                <span className="block text-slate-500 text-[11px] mt-0.5">
                  Includes leads ({leads.length}), opportunities ({opportunities.length}), and follow-ups ({followUps.length})
                </span>
              </div>
            </label>

            <label className="flex items-center gap-3 p-3 rounded-md border cursor-pointer transition-colors hover:bg-slate-50">
              <input
                type="radio"
                name="entityType"
                checked={entityType === 'leads'}
                onChange={() => setEntityType('leads')}
                className="text-slate-900 focus:ring-slate-900"
              />
              <div className="flex-1 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-900">Customer Leads Only</span>
                  <span className="block text-slate-500 text-[11px]">Contact info, company, source, notes</span>
                </div>
                <span className="font-mono tabular-nums text-slate-500 font-medium">{leads.length} records</span>
              </div>
            </label>

            <label className="flex items-center gap-3 p-3 rounded-md border cursor-pointer transition-colors hover:bg-slate-50">
              <input
                type="radio"
                name="entityType"
                checked={entityType === 'opportunities'}
                onChange={() => setEntityType('opportunities')}
                className="text-slate-900 focus:ring-slate-900"
              />
              <div className="flex-1 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-900">Opportunities & Pipeline</span>
                  <span className="block text-slate-500 text-[11px]">Deal titles, stages, estimated values, close dates</span>
                </div>
                <span className="font-mono tabular-nums text-slate-500 font-medium">{opportunities.length} records</span>
              </div>
            </label>

            <label className="flex items-center gap-3 p-3 rounded-md border cursor-pointer transition-colors hover:bg-slate-50">
              <input
                type="radio"
                name="entityType"
                checked={entityType === 'followups'}
                onChange={() => setEntityType('followups')}
                className="text-slate-900 focus:ring-slate-900"
              />
              <div className="flex-1 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-900">Follow-up Tasks</span>
                  <span className="block text-slate-500 text-[11px]">Scheduled dates, statuses, completion log</span>
                </div>
                <span className="font-mono tabular-nums text-slate-500 font-medium">{followUps.length} records</span>
              </div>
            </label>
          </div>
        </div>

        {/* File Format Selector & Download Action */}
        <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-6 shadow-xs flex flex-col justify-between">
          <div className="space-y-4">
            <h2 className="text-sm font-semibold text-slate-900">
              2. Choose File Format
            </h2>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <button
                type="button"
                onClick={() => setFormat('csv')}
                className={`p-4 rounded-lg border text-left transition-all ${
                  format === 'csv'
                    ? 'border-slate-900 bg-slate-900 text-white font-medium shadow-xs'
                    : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                }`}
              >
                <FileText className="w-5 h-5 mb-2" />
                <div className="font-bold">CSV Spreadsheet</div>
                <div className={`text-[11px] mt-1 ${format === 'csv' ? 'text-slate-300' : 'text-slate-500'}`}>
                  Standard RFC4180 for Excel, Google Sheets, or Apple Numbers.
                </div>
              </button>

              <button
                type="button"
                onClick={() => setFormat('json')}
                className={`p-4 rounded-lg border text-left transition-all ${
                  format === 'json'
                    ? 'border-slate-900 bg-slate-900 text-white font-medium shadow-xs'
                    : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                }`}
              >
                <Database className="w-5 h-5 mb-2" />
                <div className="font-bold">JSON Data</div>
                <div className={`text-[11px] mt-1 ${format === 'json' ? 'text-slate-300' : 'text-slate-500'}`}>
                  Machine-readable nested backup with complete schema metadata.
                </div>
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={handleExport}
              disabled={downloading}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-50 rounded-md transition-colors flex items-center justify-center gap-2 shadow-sm"
            >
              <Download className="w-4 h-4" />
              <span>{downloading ? 'Generating Export...' : `Download ${format.toUpperCase()} Export`}</span>
            </button>
            <p className="text-[11px] text-slate-400 text-center mt-2">
              Generated in-browser. Zero external tracking.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
};

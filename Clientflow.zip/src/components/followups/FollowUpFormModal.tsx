import React, { useState, useEffect } from 'react';
import { useCRM } from '../../context/CRMContext';
import { FollowUp } from '../../types/crm';
import { X, AlertCircle } from 'lucide-react';

interface FollowUpFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  taskToEdit?: FollowUp | null;
  preselectedLeadId?: string;
  preselectedOpportunityId?: string;
}

export const FollowUpFormModal: React.FC<FollowUpFormModalProps> = ({
  isOpen,
  onClose,
  taskToEdit,
  preselectedLeadId,
  preselectedOpportunityId
}) => {
  const { addFollowUp, rescheduleFollowUp, activeLeads, opportunities } = useCRM();

  const [title, setTitle] = useState('');
  const [leadId, setLeadId] = useState('');
  const [opportunityId, setOpportunityId] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<{ title?: string; leadId?: string; dueDate?: string }>({});

  useEffect(() => {
    if (taskToEdit) {
      setTitle(taskToEdit.title);
      setLeadId(taskToEdit.leadId);
      setOpportunityId(taskToEdit.opportunityId || '');
      // Format YYYY-MM-DDTHH:mm
      setDueDate(taskToEdit.dueDate.substring(0, 16));
      setNotes(taskToEdit.notes);
    } else {
      setTitle('');
      const defaultLead = preselectedLeadId || (activeLeads[0]?.id || '');
      setLeadId(defaultLead);
      setOpportunityId(preselectedOpportunityId || '');
      // Default due date to tomorrow 10:00 AM (2026-10-20T10:00)
      setDueDate('2026-10-20T10:00');
      setNotes('');
    }
    setErrors({});
  }, [taskToEdit, preselectedLeadId, preselectedOpportunityId, activeLeads, isOpen]);

  if (!isOpen) return null;

  // Filter opportunities belonging to the selected lead
  const leadOpportunities = opportunities.filter(o => o.leadId === leadId);

  const validate = () => {
    const errs: { title?: string; leadId?: string; dueDate?: string } = {};

    if (!title.trim()) {
      errs.title = 'Task title is required.';
    }

    if (!leadId) {
      errs.leadId = 'A linked customer lead is required.';
    }

    if (!dueDate) {
      errs.dueDate = 'Due date and time are required.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    if (taskToEdit) {
      rescheduleFollowUp(taskToEdit.id, dueDate, notes.trim());
      onClose();
    } else {
      const res = addFollowUp({
        title: title.trim(),
        leadId,
        opportunityId: opportunityId || undefined,
        dueDate,
        notes: notes.trim()
      });

      if (res.success) {
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div 
        className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-150"
        role="dialog"
        aria-labelledby="followup-modal-title"
      >
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div>
            <h3 id="followup-modal-title" className="text-base font-bold text-slate-900">
              {taskToEdit ? 'Reschedule Follow-up Task' : 'Schedule Customer Follow-up'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Set reminders for client check-ins, proposal reviews, or calls
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded-md transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Task Action / Title <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Call Maya to review quotation feedback"
              className={`w-full px-3 py-2 text-sm bg-white border rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:border-slate-900 transition-colors ${
                errors.title ? 'border-rose-400 bg-rose-50/20' : 'border-slate-300'
              }`}
            />
            {errors.title && (
              <p className="text-xs text-rose-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> {errors.title}
              </p>
            )}
          </div>

          {/* Customer Lead */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Associated Customer <span className="text-rose-500">*</span>
            </label>
            <select
              value={leadId}
              onChange={e => {
                setLeadId(e.target.value);
                setOpportunityId(''); // reset opp on lead change
              }}
              disabled={!!taskToEdit}
              className={`w-full px-3 py-2 text-sm bg-white border rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:border-slate-900 transition-colors ${
                errors.leadId ? 'border-rose-400 bg-rose-50/20' : 'border-slate-300'
              }`}
            >
              {activeLeads.length === 0 ? (
                <option value="">No active leads available</option>
              ) : (
                activeLeads.map(lead => (
                  <option key={lead.id} value={lead.id}>
                    {lead.name} {lead.company ? `(${lead.company})` : ''}
                  </option>
                ))
              )}
            </select>
            {errors.leadId && (
              <p className="text-xs text-rose-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> {errors.leadId}
              </p>
            )}
          </div>

          {/* Optional Linked Opportunity */}
          {leadOpportunities.length > 0 && !taskToEdit && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Link to Opportunity (Optional)
              </label>
              <select
                value={opportunityId}
                onChange={e => setOpportunityId(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900 transition-colors"
              >
                <option value="">No specific opportunity</option>
                {leadOpportunities.map(opp => (
                  <option key={opp.id} value={opp.id}>
                    {opp.title} ({opp.stage})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Due Date & Time */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Due Date & Time <span className="text-rose-500">*</span>
            </label>
            <input
              type="datetime-local"
              value={dueDate}
              onChange={e => setDueDate(e.target.value)}
              className={`w-full px-3 py-2 text-sm bg-white border rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:border-slate-900 transition-colors font-mono tabular-nums ${
                errors.dueDate ? 'border-rose-400 bg-rose-50/20' : 'border-slate-300'
              }`}
            />
            {errors.dueDate && (
              <p className="text-xs text-rose-600 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> {errors.dueDate}
              </p>
            )}
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Follow-up Details & Context
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="What needs to be discussed, specific questions to answer..."
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:border-slate-900 transition-colors resize-none"
            />
          </div>

          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors shadow-sm"
            >
              {taskToEdit ? 'Save Rescheduled Date' : 'Schedule Follow-up'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};

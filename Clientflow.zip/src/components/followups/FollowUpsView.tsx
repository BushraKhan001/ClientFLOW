import React, { useMemo } from 'react';
import { useCRM, REFERENCE_DATE } from '../../context/CRMContext';
import { FollowUp } from '../../types/crm';
import { 
  CheckCircle2, 
  Calendar, 
  Clock, 
  Plus, 
  AlertCircle, 
  CalendarCheck, 
  User, 
  Building,
  RotateCcw
} from 'lucide-react';

interface FollowUpsViewProps {
  onOpenNewFollowUp: () => void;
  onRescheduleFollowUp: (task: FollowUp) => void;
  onOpenLead: (leadId: string) => void;
  onOpenOpportunity: (oppId: string) => void;
}

export const FollowUpsView: React.FC<FollowUpsViewProps> = ({
  onOpenNewFollowUp,
  onRescheduleFollowUp,
  onOpenLead,
  onOpenOpportunity
}) => {
  const { 
    followUps, 
    followUpFilter, 
    setFollowUpFilter, 
    completeFollowUp,
    currentWorkspace 
  } = useCRM();

  const now = REFERENCE_DATE.getTime();
  const todayStr = '2026-10-19';

  // Counts
  const counts = useMemo(() => {
    let overdue = 0;
    let dueToday = 0;
    let upcoming = 0;
    let completed = 0;

    followUps.forEach(t => {
      if (t.status === 'completed') {
        completed++;
      } else if (t.status === 'pending') {
        const time = new Date(t.dueDate).getTime();
        if (time < now) {
          overdue++;
        } else if (t.dueDate.startsWith(todayStr)) {
          dueToday++;
        } else {
          upcoming++;
        }
      }
    });

    return { all: followUps.length, overdue, dueToday, upcoming, completed };
  }, [followUps, now, todayStr]);

  const filteredTasks = useMemo(() => {
    return followUps.filter(t => {
      const time = new Date(t.dueDate).getTime();
      const isOverdue = t.status === 'pending' && time < now;
      const isToday = t.status === 'pending' && t.dueDate.startsWith(todayStr);
      const isUpcoming = t.status === 'pending' && time >= now && !t.dueDate.startsWith(todayStr);

      if (followUpFilter === 'overdue') return isOverdue;
      if (followUpFilter === 'due_today') return isToday;
      if (followUpFilter === 'upcoming') return isUpcoming;
      if (followUpFilter === 'completed') return t.status === 'completed';
      return true;
    }).sort((a, b) => {
      // Pending first, then by due date
      if (a.status !== b.status) return a.status === 'pending' ? -1 : 1;
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    });
  }, [followUps, followUpFilter, now, todayStr]);

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Follow-up Tasks & Reminders
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Never lose track of a prospect or scheduled client review
          </p>
        </div>

        <button
          onClick={onOpenNewFollowUp}
          className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors flex items-center gap-1.5 self-start sm:self-auto shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Schedule Follow-up</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
        <button
          onClick={() => setFollowUpFilter('all')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            followUpFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          All ({counts.all})
        </button>

        <button
          onClick={() => setFollowUpFilter('overdue')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1 ${
            followUpFilter === 'overdue' 
              ? 'bg-white text-rose-700 font-semibold shadow-xs' 
              : counts.overdue > 0 ? 'text-rose-600 font-medium hover:text-rose-800' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          {counts.overdue > 0 && <AlertCircle className="w-3.5 h-3.5 text-rose-600" />}
          <span>Overdue ({counts.overdue})</span>
        </button>

        <button
          onClick={() => setFollowUpFilter('due_today')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            followUpFilter === 'due_today' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Due Today ({counts.dueToday})
        </button>

        <button
          onClick={() => setFollowUpFilter('upcoming')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            followUpFilter === 'upcoming' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Upcoming ({counts.upcoming})
        </button>

        <button
          onClick={() => setFollowUpFilter('completed')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
            followUpFilter === 'completed' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Completed ({counts.completed})
        </button>
      </div>

      {/* Task List */}
      <div className="bg-white border border-slate-200 rounded-lg divide-y divide-slate-100 overflow-hidden shadow-xs">
        {filteredTasks.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            {followUpFilter === 'overdue' ? (
              <>
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                <div className="text-sm font-semibold text-slate-800">
                  No Overdue Tasks!
                </div>
                <div className="text-xs text-slate-500 max-w-sm mx-auto">
                  You are completely caught up on outstanding customer follow-ups.
                </div>
              </>
            ) : followUpFilter === 'due_today' ? (
              <>
                <CalendarCheck className="w-8 h-8 text-slate-300 mx-auto" />
                <div className="text-sm font-semibold text-slate-800">
                  No tasks due today
                </div>
                <div className="text-xs text-slate-500 max-w-sm mx-auto">
                  Check upcoming tasks or schedule outreach for a new prospect.
                </div>
              </>
            ) : (
              <>
                <Clock className="w-8 h-8 text-slate-300 mx-auto" />
                <div className="text-sm font-semibold text-slate-800">
                  No tasks in this view
                </div>
                <div className="text-xs text-slate-500 max-w-sm mx-auto">
                  Schedule follow-ups with your leads to stay on top of quotations and client calls.
                </div>
                <button
                  onClick={onOpenNewFollowUp}
                  className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors inline-flex items-center gap-1.5 shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Schedule Task</span>
                </button>
              </>
            )}
          </div>
        ) : (
          filteredTasks.map(task => {
            const time = new Date(task.dueDate).getTime();
            const isOverdue = task.status === 'pending' && time < now;
            const isToday = task.status === 'pending' && task.dueDate.startsWith(todayStr);
            const isCompleted = task.status === 'completed';

            return (
              <div 
                key={task.id}
                className="p-4 flex items-start gap-3.5 hover:bg-slate-50 transition-colors"
              >
                {/* 1-click complete toggle */}
                <button
                  onClick={() => !isCompleted && completeFollowUp(task.id)}
                  disabled={isCompleted}
                  className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center transition-colors shrink-0 ${
                    isCompleted
                      ? 'bg-emerald-600 border-emerald-600 text-white cursor-default'
                      : 'border-slate-300 hover:border-emerald-500 hover:bg-emerald-50 text-transparent'
                  }`}
                  aria-label="Toggle completion status"
                  title={isCompleted ? 'Completed task' : 'Mark complete'}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                </button>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-3">
                    <span className={`text-sm font-semibold ${
                      isCompleted ? 'line-through text-slate-400' : 'text-slate-900'
                    }`}>
                      {task.title}
                    </span>

                    {/* Due Date & State Badge */}
                    <div className="text-right shrink-0">
                      <span className={`text-xs font-mono tabular-nums font-medium ${
                        isOverdue
                          ? 'text-rose-600 font-bold'
                          : isToday
                          ? 'text-amber-700 font-bold'
                          : isCompleted
                          ? 'text-emerald-700'
                          : 'text-slate-600'
                      }`}>
                        {isOverdue && 'Overdue · '}
                        {isToday && 'Due Today · '}
                        {new Date(task.dueDate).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>

                  {/* Customer / Opportunity context */}
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                    <button
                      onClick={() => onOpenLead(task.leadId)}
                      className="hover:text-slate-900 hover:underline inline-flex items-center gap-1 truncate"
                    >
                      <User className="w-3 h-3 text-slate-400 shrink-0" />
                      <span>{task.leadName}</span>
                    </button>

                    {task.leadCompany && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="truncate">{task.leadCompany}</span>
                      </>
                    )}

                    {task.opportunityTitle && task.opportunityId && (
                      <>
                        <span aria-hidden="true">·</span>
                        <button
                          onClick={() => onOpenOpportunity(task.opportunityId!)}
                          className="text-slate-500 hover:text-slate-900 hover:underline truncate"
                        >
                          Deal: {task.opportunityTitle}
                        </button>
                      </>
                    )}
                  </div>

                  {task.notes && (
                    <p className="text-xs text-slate-600 mt-1.5 leading-relaxed line-clamp-2">
                      {task.notes}
                    </p>
                  )}
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  {!isCompleted && (
                    <>
                      <button
                        onClick={() => onRescheduleFollowUp(task)}
                        className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded transition-colors"
                      >
                        Reschedule
                      </button>
                      <button
                        onClick={() => completeFollowUp(task.id)}
                        className="px-3 py-1 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded transition-colors shadow-xs"
                      >
                        Complete
                      </button>
                    </>
                  )}
                  {isCompleted && (
                    <span className="text-[11px] text-slate-400 italic">
                      Done
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
};

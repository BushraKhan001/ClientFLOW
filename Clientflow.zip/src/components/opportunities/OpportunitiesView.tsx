import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { OpportunityStage } from '../../types/crm';
import { 
  Search, 
  Plus, 
  ChevronRight, 
  Calendar, 
  DollarSign, 
  User, 
  Building,
  Briefcase
} from 'lucide-react';

interface OpportunitiesViewProps {
  onOpenNewOpportunity: () => void;
  onSelectOpportunity: (id: string) => void;
}

export const OpportunitiesView: React.FC<OpportunitiesViewProps> = ({
  onOpenNewOpportunity,
  onSelectOpportunity
}) => {
  const { opportunities, setOpportunityStage, metrics, currentWorkspace } = useCRM();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'won' | 'lost'>('all');

  const filteredOpportunities = useMemo(() => {
    return opportunities.filter(o => {
      if (statusFilter !== 'all' && o.status !== statusFilter) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = o.title.toLowerCase().includes(q);
        const matchesLead = o.leadName?.toLowerCase().includes(q);
        const matchesCompany = o.leadCompany?.toLowerCase().includes(q);
        const matchesStage = o.stage.toLowerCase().includes(q);
        if (!matchesTitle && !matchesLead && !matchesCompany && !matchesStage) return false;
      }

      return true;
    }).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }, [opportunities, statusFilter, searchQuery]);

  const openCount = opportunities.filter(o => o.status === 'open').length;
  const wonCount = opportunities.filter(o => o.status === 'won').length;
  const lostCount = opportunities.filter(o => o.status === 'lost').length;

  return (
    <div className="space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Sales Opportunities & Pipeline
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Track revenue progression from initial qualification through won outcomes
          </p>
        </div>

        <button
          onClick={onOpenNewOpportunity}
          className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors flex items-center gap-1.5 self-start sm:self-auto shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>Add Opportunity</span>
        </button>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Open Pipeline Value</div>
          <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
            ${metrics.openPipelineValue.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {openCount} active opportunities in flight
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Won Revenue</div>
          <div className="text-xl font-bold font-mono tabular-nums text-emerald-600 mt-1">
            ${metrics.wonOpportunitiesValue.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {wonCount} deals successfully closed
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Closed Lost Count</div>
          <div className="text-xl font-bold font-mono tabular-nums text-slate-700 mt-1">
            {lostCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Reason captured for performance insights
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search deals, clients, stages..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900 focus:border-slate-900 transition-colors shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2 text-xs text-slate-400 hover:text-slate-600"
            >
              Clear
            </button>
          )}
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg shrink-0 self-start sm:self-auto">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              statusFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            All ({opportunities.length})
          </button>
          <button
            onClick={() => setStatusFilter('open')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              statusFilter === 'open' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Open ({openCount})
          </button>
          <button
            onClick={() => setStatusFilter('won')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              statusFilter === 'won' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Won ({wonCount})
          </button>
          <button
            onClick={() => setStatusFilter('lost')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              statusFilter === 'lost' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Lost ({lostCount})
          </button>
        </div>

      </div>

      {/* Opportunities Table */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-xs">
        {filteredOpportunities.length === 0 ? (
          <div className="p-12 text-center">
            {searchQuery ? (
              <div className="space-y-3">
                <div className="text-sm font-semibold text-slate-800">
                  No matching opportunities
                </div>
                <div className="text-xs text-slate-500 max-w-sm mx-auto">
                  No deals match "{searchQuery}" in {currentWorkspace.name}.
                </div>
                <button
                  onClick={() => setSearchQuery('')}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors"
                >
                  Clear search query
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <Briefcase className="w-8 h-8 text-slate-300 mx-auto" />
                <div className="text-sm font-semibold text-slate-800">
                  No sales opportunities recorded
                </div>
                <div className="text-xs text-slate-500 max-w-sm mx-auto">
                  Create an opportunity linked to an active lead to begin tracking stages and values.
                </div>
                <button
                  onClick={onOpenNewOpportunity}
                  className="px-4 py-2 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors shadow-sm inline-flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add First Opportunity</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="px-5 py-3">Opportunity Name</th>
                  <th className="px-5 py-3">Linked Customer</th>
                  <th className="px-5 py-3 text-right">Estimated Value</th>
                  <th className="px-5 py-3">Stage</th>
                  <th className="px-5 py-3 text-right">Target Close</th>
                  <th className="px-5 py-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredOpportunities.map(opp => (
                  <tr
                    key={opp.id}
                    onClick={() => onSelectOpportunity(opp.id)}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                  >
                    {/* Title */}
                    <td className="px-5 py-3.5 min-w-[220px]">
                      <div className="font-semibold text-slate-900 group-hover:text-slate-950 transition-colors">
                        {opp.title}
                      </div>
                      {opp.notes && (
                        <div className="text-slate-400 truncate max-w-xs text-[11px] mt-0.5">
                          {opp.notes}
                        </div>
                      )}
                    </td>

                    {/* Customer & Company */}
                    <td className="px-5 py-3.5 min-w-[180px]">
                      <div className="font-medium text-slate-800">
                        {opp.leadName}
                      </div>
                      {opp.leadCompany && (
                        <div className="text-slate-500 flex items-center gap-1 mt-0.5 text-[11px]">
                          <Building className="w-3 h-3 text-slate-400" />
                          <span className="truncate">{opp.leadCompany}</span>
                        </div>
                      )}
                    </td>

                    {/* Estimated Value */}
                    <td className="px-5 py-3.5 text-right font-mono tabular-nums whitespace-nowrap">
                      {opp.value !== null ? (
                        <span className="font-bold text-slate-900">
                          ${opp.value.toLocaleString()}
                        </span>
                      ) : (
                        <span className="text-slate-400 italic">Not set</span>
                      )}
                    </td>

                    {/* Stage & Status */}
                    <td className="px-5 py-3.5 whitespace-nowrap" onClick={e => e.stopPropagation()}>
                      <select
                        value={opp.stage}
                        onChange={e => setOpportunityStage(opp.id, e.target.value as OpportunityStage)}
                        className={`text-xs font-semibold py-1 px-2 rounded-md border transition-colors ${
                          opp.status === 'won'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : opp.status === 'lost'
                            ? 'bg-rose-50 text-rose-800 border-rose-300'
                            : 'bg-white text-slate-800 border-slate-300'
                        }`}
                      >
                        <option value="Discovery">Discovery</option>
                        <option value="Proposal Sent">Proposal Sent</option>
                        <option value="Negotiation">Negotiation</option>
                        <option value="Won">Won</option>
                        <option value="Lost">Lost</option>
                      </select>
                    </td>

                    {/* Close target */}
                    <td className="px-5 py-3.5 text-right font-mono tabular-nums text-slate-600 whitespace-nowrap">
                      {opp.expectedCloseDate}
                    </td>

                    {/* Action */}
                    <td className="px-5 py-3.5 text-right whitespace-nowrap">
                      <button
                        onClick={() => onSelectOpportunity(opp.id)}
                        className="text-slate-400 group-hover:text-slate-700 p-1 rounded transition-colors inline-flex items-center gap-0.5 text-xs font-medium"
                      >
                        <span>View</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};

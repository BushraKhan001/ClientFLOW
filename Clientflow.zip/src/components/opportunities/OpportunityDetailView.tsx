import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { OpportunityStage } from '../../types/crm';
import { 
  ArrowLeft, 
  Calendar, 
  Plus, 
  Edit3, 
  Trophy, 
  XCircle, 
  Building, 
  User, 
  CheckCircle2,
  DollarSign
} from 'lucide-react';

interface OpportunityDetailViewProps {
  opportunityId: string;
  onBack: () => void;
  onEdit: () => void;
  onScheduleFollowUp: () => void;
}

const STAGES: OpportunityStage[] = [
  'Discovery',
  'Proposal Sent',
  'Negotiation',
  'Won',
  'Lost'
];

export const OpportunityDetailView: React.FC<OpportunityDetailViewProps> = ({
  opportunityId,
  onBack,
  onEdit,
  onScheduleFollowUp
}) => {
  const { 
    opportunities, 
    setOpportunityStage, 
    followUps, 
    completeFollowUp,
    activities, 
    setSelectedLeadId, 
    setCurrentTab 
  } = useCRM();

  const [lossReasonInput, setLossReasonInput] = useState('');
  const [showLossModal, setShowLossModal] = useState(false);

  const opp = opportunities.find(o => o.id === opportunityId);

  if (!opp) {
    return (
      <div className="bg-white border border-slate-200 rounded-lg p-12 text-center">
        <h3 className="text-base font-semibold text-slate-900">Opportunity Not Found</h3>
        <p className="text-xs text-slate-500 mt-1">
          This record may belong to a different workspace or was removed.
        </p>
        <button
          onClick={onBack}
          className="mt-4 px-4 py-2 text-xs font-medium text-white bg-slate-900 rounded-md hover:bg-slate-800 transition-colors"
        >
          Return to Opportunities
        </button>
      </div>
    );
  }

  const linkedTasks = followUps.filter(f => f.opportunityId === opp.id);
  const oppActivities = activities.filter(a => a.opportunityId === opp.id || (a.leadId === opp.leadId && a.type.startsWith('opportunity')));

  const handleStageClick = (stage: OpportunityStage) => {
    if (stage === 'Lost') {
      setShowLossModal(true);
    } else {
      setOpportunityStage(opp.id, stage);
    }
  };

  const confirmLoss = () => {
    setOpportunityStage(opp.id, 'Lost', lossReasonInput.trim() || 'Budget/Scope misalignment');
    setShowLossModal(false);
    setLossReasonInput('');
  };

  const handleOpenLead = (leadId: string) => {
    setSelectedLeadId(leadId);
    setCurrentTab('leads');
  };

  return (
    <div className="space-y-6">
      
      {/* Breadcrumb & Actions */}
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Opportunities</span>
        </button>

        <div className="flex items-center gap-2">
          {opp.status !== 'won' && (
            <button
              onClick={() => setOpportunityStage(opp.id, 'Won')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-md transition-colors shadow-xs"
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>Mark Won</span>
            </button>
          )}

          {opp.status !== 'lost' && (
            <button
              onClick={() => setShowLossModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-md transition-colors"
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>Mark Lost</span>
            </button>
          )}

          <button
            onClick={onEdit}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-md transition-colors shadow-xs"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit</span>
          </button>
        </div>
      </div>

      {/* Main Header Card */}
      <div className="bg-white border border-slate-200 rounded-lg p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">
              {opp.title}
            </h1>

            {/* Linked Lead */}
            <div className="flex items-center gap-2 text-xs text-slate-600 mt-2">
              <span className="text-slate-400">Customer:</span>
              <button
                onClick={() => handleOpenLead(opp.leadId)}
                className="font-semibold text-slate-900 hover:underline inline-flex items-center gap-1"
              >
                <User className="w-3.5 h-3.5 text-slate-400" />
                <span>{opp.leadName}</span>
              </button>
              {opp.leadCompany && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-slate-500 inline-flex items-center gap-1">
                    <Building className="w-3.5 h-3.5 text-slate-400" />
                    <span>{opp.leadCompany}</span>
                  </span>
                </>
              )}
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-500 mt-3">
              <span className="inline-flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                Target Close: <span className="font-mono tabular-nums text-slate-800">{opp.expectedCloseDate}</span>
              </span>
              <span aria-hidden="true">·</span>
              <span>Created {new Date(opp.createdAt).toLocaleDateString()}</span>
            </div>
          </div>

          {/* Deal Value */}
          <div className="sm:text-right shrink-0">
            <div className="text-xs text-slate-500">Estimated Value</div>
            <div className="text-3xl font-bold font-mono tabular-nums text-slate-900 mt-0.5">
              {opp.value !== null ? `$${opp.value.toLocaleString()}` : 'Unspecified'}
            </div>
            <div className="text-xs mt-1 font-medium">
              {opp.status === 'open' && <span className="text-blue-600">Active Open Pipeline</span>}
              {opp.status === 'won' && <span className="text-emerald-600 font-semibold">Closed Won Revenue</span>}
              {opp.status === 'lost' && <span className="text-rose-600 font-semibold">Closed Lost</span>}
            </div>
          </div>
        </div>

        {/* Loss Reason notice if lost */}
        {opp.stage === 'Lost' && opp.lossReason && (
          <div className="mt-4 p-3 bg-rose-50 border border-rose-200 rounded-md text-xs text-rose-800">
            <span className="font-semibold">Loss Reason: </span>
            {opp.lossReason}
          </div>
        )}

        {/* Interactive Stage Pipeline Stepper */}
        <div className="mt-6 pt-6 border-t border-slate-100">
          <div className="text-xs font-semibold text-slate-500 mb-2.5">
            Pipeline Stage Progression (Click to move stage):
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {STAGES.map(s => {
              const isCurrent = opp.stage === s;
              const isWon = s === 'Won';
              const isLost = s === 'Lost';

              return (
                <button
                  key={s}
                  onClick={() => handleStageClick(s)}
                  className={`p-2.5 text-xs text-left rounded-md border transition-all ${
                    isCurrent
                      ? isWon
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold shadow-xs'
                        : isLost
                        ? 'border-rose-500 bg-rose-50 text-rose-900 font-bold shadow-xs'
                        : 'border-slate-900 bg-slate-900 text-white font-bold shadow-xs'
                      : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-600'
                  }`}
                >
                  <div className="text-[10px] uppercase tracking-wider opacity-75">
                    {s === 'Won' || s === 'Lost' ? 'Outcome' : 'Stage'}
                  </div>
                  <div className="mt-0.5 truncate">{s}</div>
                </button>
              );
            })}
          </div>
        </div>

        {opp.notes && (
          <div className="mt-4 pt-4 border-t border-slate-100 text-xs text-slate-600 leading-relaxed">
            <span className="font-semibold text-slate-700">Scope Notes: </span>
            {opp.notes}
          </div>
        )}
      </div>

      {/* Linked Tasks and Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Linked Tasks */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900">
              Tasks Linked to this Deal ({linkedTasks.length})
            </h2>
            <button
              onClick={onScheduleFollowUp}
              className="text-xs font-medium text-slate-700 hover:text-slate-900 inline-flex items-center gap-1 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Schedule Task</span>
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg divide-y divide-slate-100 overflow-hidden shadow-xs">
            {linkedTasks.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                No follow-up tasks linked specifically to this opportunity.
              </div>
            ) : (
              linkedTasks.map(task => {
                const isDone = task.status === 'completed';
                return (
                  <div key={task.id} className="p-4 flex items-start gap-3">
                    <button
                      onClick={() => !isDone && completeFollowUp(task.id)}
                      disabled={isDone}
                      className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center transition-colors shrink-0 ${
                        isDone 
                          ? 'bg-emerald-600 border-emerald-600 text-white' 
                          : 'border-slate-300 hover:border-emerald-500 text-transparent'
                      }`}
                      aria-label="Toggle task completion"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </button>
                    <div className="min-w-0">
                      <div className={`text-xs font-semibold ${isDone ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                        {task.title}
                      </div>
                      <div className="text-[11px] font-mono tabular-nums text-slate-500 mt-0.5">
                        Due: {new Date(task.dueDate).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Opportunity Activity Timeline */}
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-slate-900">
            Deal History
          </h2>
          <div className="bg-white border border-slate-200 rounded-lg p-5 shadow-xs space-y-3">
            {oppActivities.length === 0 ? (
              <div className="text-xs text-slate-500 text-center py-4">
                No recorded activity for this opportunity yet.
              </div>
            ) : (
              oppActivities.map(act => (
                <div key={act.id} className="text-xs flex items-start gap-2.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1 font-semibold text-slate-800">
                      <span>{act.title}</span>
                      <span className="text-[10px] font-mono tabular-nums text-slate-400 font-normal">
                        {new Date(act.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                      </span>
                    </div>
                    <p className="text-slate-600 mt-0.5 leading-relaxed">
                      {act.description}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* Loss Reason Modal */}
      {showLossModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white rounded-lg border border-slate-200 shadow-xl max-w-md w-full p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              Record Opportunity Loss
            </h3>
            <p className="text-xs text-slate-500">
              Capturing the loss reason helps identify sales patterns and budget mismatches for future reference.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Loss Reason / Feedback
              </label>
              <textarea
                rows={3}
                value={lossReasonInput}
                onChange={e => setLossReasonInput(e.target.value)}
                placeholder="e.g. Client budget reduced, competitor selected, project deferred to next year..."
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-md focus:outline-hidden focus:ring-2 focus:ring-slate-900 resize-none"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setShowLossModal(false)}
                className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100 rounded-md"
              >
                Cancel
              </button>
              <button
                onClick={confirmLoss}
                className="px-4 py-1.5 text-xs font-medium text-white bg-rose-600 hover:bg-rose-700 rounded-md shadow-xs"
              >
                Confirm Lost
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
